
        import java.util.*;
        public class Challenge3 { 
			public static void main (String args[]){
			String[] p1 = {"SaharaNet", "Temime", "ICS", "TechBench", "Challenge", "Java", "C", "Plage Menzel Temime", "Program", "C++"};
		int[] p2 = {3, 1, 0, 5, 6, 2, 1, 6, 3, 1};
		String[] o = {"NetSahara", "eTemim", "ICS", "BenchTech", "llengeCha", "vaJa", "C", "TemimePlage Menzel ", "ramProg", "+C+"};
		
		boolean[] result = new boolean[p1.length];
		int score = 0;
		
		for(int i = 0; i < p1.length; i++) {
			try {
				String r = rotateString(p1[i], p2[i]);
				result[i] = (o[i].equals(r));
				
				System.out.print("rotateString(" + p1[i] + ", " + p2[i] +")");
				System.out.print(" ==> " + r);
				System.out.print("  Correct Result: " + o[i]);
				System.out.print(" -" + result[i] + "\n");
			} catch (Exception e) {
				System.out.print("rotateString(" + p1[i] + ", " + p2[i] + ")");
				System.out.print(" ==> " + e.toString());
				System.out.print("  Correct Result: " + o[i]);
				System.out.print(" -" + result[i] + "\n");
			}
		}
		
		for(boolean b : result)
			if(b)
				score++;
		
		if(score == result.length)
				score = score + score;
		
		System.out.println(score); 
			}
			public static String rotateString(String s, int i) {
			
{
int [] arr = new int [s.length];
for(int i=0; i<s.length; i++){
arr[i] = s.charAt(i);
 }

} 
		} 
		}