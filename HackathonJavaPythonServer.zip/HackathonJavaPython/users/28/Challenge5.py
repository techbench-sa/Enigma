def lengthLastWord(s):
	return len(s.split(" ")[-1])

p1 = ["Hello Word", "Sahara Net", "I will win", "TechBench ", "Easy  Challenge", "", "did you   solve it ", "Summer Robot", "alphabet C", "C   plus plus"];
o = [4, 3, 3, 9, 9, 0, 2, 5, 1, 4];
		
#		boolean[] result = new boolean[p1.length];
result = [];
score = 0;
		
for i in range(len(p1)):
	r = lengthLastWord(p1[i]);
	if (o[i] == r):
        	result.append(True)
	else:
        	result.append(False)
					
	print("lengthLastWord(" + p1[i] +")",end="");
	print(" ==> " + str(r), end="");
	print("  Correct Result: " + str(o[i]) , end="");
	if (result[i]):
        	print(" -true")
	else:
		print(" -false")
				
validTests = 0;
for i in range(len(result)):
    if (result[i]):
        validTests = validTests + 1;

# Score Counting: 1pts for every valid test 
# Doubling the score if all test cases are valid
score = validTests;

if (validTests == len(result)):
    score += validTests;

print("Score is: " + str(score));