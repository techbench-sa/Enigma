def replacePlus(s, word):
	i=0
	while i<len(s):
		if not s[i] in word:
			s=s[:i]+"+"+s[i+1:]
		i=i+1
	return s	

p1 = ["SaharaNet", "Menzel", "ICS", "TechBench", "Challenge", "Java", "C", "Club Robotique", "Program", "C++"];
p2 = ["ara", "z", "ICS", "e", "l", "a", "c", "x", "ram", "C"];
o = ["+++ara+++", "+++z++", "ICS", "+e+++e+++","+++ll++++", "+a+a", "+", "++++++++++++++", "++++ram", "C++"];	

		
#		boolean[] result = new boolean[p1.length];
result = [];
score = 0;
		
for i in range(len(p1)):
	r = replacePlus(p1[i], p2[i]);
	if (o[i] == r):
        	result.append(True)
	else:
        	result.append(False)
					
	print("replacePlus(" + p1[i] + ", " + str(p2[i]) +")",end="");
	print(" ==> " + str(r), end="");
	print("  Correct Result: " + str(o[i]) , end="");
	if (result[i]):
        	print(" -true")
	else:
		print(" -false")
				
validTests = 0;
for i in range(len(result)):
    if (result[i]):
        validTests = validTests + 1;

# Score Counting: 1pts for every valid test 
# Doubling the score if all test cases are valid
score = validTests;

if (validTests == len(result)):
    score += validTests;

print("Score is: " + str(score));