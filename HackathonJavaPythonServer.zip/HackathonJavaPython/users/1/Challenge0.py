def removeChar(str,i):
	return "kupm";

parameter1 = ["kfupm","kfupm","kfupm","Hi","Hi","ccse","ccse","ccse","ccse","chocolate"]

parameter2 = [1,0,4,0,1,0,1,2,3,8];
correctOutput = ["kupm","fupm","kfup","i","H","cse","cse","cce","ccs","chocolat"];

testResult = [] # new boolean[parameter1.length];

for i in range(len(correctOutput)):
    testR = removeChar(parameter1[i],parameter2[i]);
    if (testR == correctOutput[i]):
        testResult.append(True)
    else:
        testResult.append(False)
    #testResult.append(testR==correctOutput[i]);
    print("removeChar(\"" + parameter1[i] + "\"," + str(parameter2[i]) + ")",end="")
    print(" ==> \"" + testR +"\"", end="")
    print("  Correct Result: \"" + correctOutput[i] + "\"", end=""),
    if (testResult[i]):
        print(" -true")
    else:
        print(" -false")
    
    #print(" -" + str(testResult[i]) + "\n");



validTests = 0;
for i in range(len(testResult)):
    if (testResult[i]):
        validTests = validTests + 1;

# Score Counting: 1pts for every valid test 
# Doubling the score if all test cases are valid
score = validTests;

if (validTests == len(testResult)):
    score += validTests;

print("Score is: " + str(score));