
        import java.util.*;
        public class Challenge5 { 
			public static void main (String args[]){
			String[] p1 = {"Hello Word", "Sahara Net", "I will win", "TechBench ", "Easy  Challenge", "", "did you   solve it ", "Summer Robot", "alphabet C", "C   plus plus"};
		int[] o = {4, 3, 3, 9, 9, 0, 2, 5, 1, 4};
		
		boolean[] result = new boolean[p1.length];
		int score = 0;

		for(int i = 0; i < p1.length; i++) {
			try {
				int r = LengthOfLastWord(p1[i]);
				result[i] = (o[i] == (r));
				
				System.out.print("LengthOfLastWord(" + p1[i] + ")");
				System.out.print(" ==> " + r);
				System.out.print("  Correct Result: " + o[i]);
				System.out.print(" -" + result[i] + "\n");
			} catch (Exception e) {
				System.out.print("LengthOfLastWord(" + p1[i] +  ")");
				System.out.print(" ==> " + e.toString());
				System.out.print("  Correct Result: " + o[i]);
				System.out.print(" -" + result[i] + "\n");
			}
		}
		
		for(boolean b : result)
			if(b)
				score++;
		
		if(score == result.length)
				score = score + score;
		
		System.out.println(score); 
			}
			public static int LengthOfLastWord(String s) {
			String r = "";
if(s.lastIndexOf(' ') < 0)
	return 0;
r = s.substring(s.lastIndexOf(' '));
return r.length() - 1; 
		} 
		}