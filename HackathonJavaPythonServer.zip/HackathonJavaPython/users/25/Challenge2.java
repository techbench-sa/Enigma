
        import java.util.*;
        public class Challenge2 { 
			public static void main (String args[]){
			String[] p1 = {"Menzel Temime", "Nabeul", "ICS", "TechBench", "Challenge", "Java", "C", "Plage Menzel Temime", "Program", "C++"};
		char[] p2 = {'e', 'p', 'S', 'c', 'l', 'i', 'c', ' ', 'm', '+'};
		int[] o = {4, 0, 1, 2, 2, 0, 0, 2, 1, 2};
		
		boolean[] result = new boolean[p1.length];
		int score = 0;
		
		for(int i = 0; i < p1.length; i++) {
			try {
				int r = countChar(p1[i], p2[i]);
				result[i] = (o[i] == (r));
				
				System.out.print("countChar(" + p1[i] + ", " + p2[i] +")");
				System.out.print(" ==> " + r);
				System.out.print("  Correct Result: " + o[i]);
				System.out.print(" -" + result[i] + "\n");
			} catch (Exception e) {
				System.out.print("countChar(" + p1[i] + ", " + p2[i] + ")");
				System.out.print(" ==> " + e.toString());
				System.out.print("  Correct Result: " + o[i]);
				System.out.print(" -" + result[i] + "\n");
			}
		}
		
		for(boolean b : result)
			if(b)
				score++;
		
		if(score == result.length)
				score = score + score;
		
		System.out.println(score); 
			}
			public static int countChar(String s, char p) {
			int r = 0;
for(int i =0 ; i < s.length() ; i++){
	if(s.charAt(i) == p)
		r++;
}
return r; 
		} 
		}