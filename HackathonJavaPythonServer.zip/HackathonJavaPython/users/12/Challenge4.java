
        import java.util.*;
        public class Challenge4 { 
			public static void main (String args[]){
			String[] p1 = {"SaharaNet", "Menzel", "ICS", "TechBench", "Challenge", "Java", "C", "Club Robotique", "Program", "C++"};
		String[] p2 = {"ara", "z", "ICS", "e", "l", "a", "c", "x", "ram", "C"};
		String[] o = {"+++ara+++", "+++z++", "ICS", "+e+++e+++","+++ll++++", "+a+a", "+", "++++++++++++++", "++++ram", "C++"};
		
		boolean[] result = new boolean[p1.length];
		int score = 0;
		
			
		for(int i = 0; i < p1.length; i++) {
			try {
				String r = replacePlus(p1[i], p2[i]);
				result[i] = (o[i].equals(r));
				
				System.out.print("replacePlus(" + p1[i] + ", " + p2[i] +")");
				System.out.print(" ==> " + r);
				System.out.print("  Correct Result: " + o[i]);
				System.out.print(" -" + result[i] + "\n");
			} catch (Exception e) {
				System.out.print("replacePlus(" + p1[i] + ", " + p2[i] + ")");
				System.out.print(" ==> " + e.toString());
				System.out.print("  Correct Result: " + o[i]);
				System.out.print(" -" + result[i] + "\n");
			}
		}
		
		for(boolean b : result)
			if(b)
				score++;
		
		if(score == result.length)
				score = score + score;
		
		System.out.println(score); 
			}
			public static String replacePlus(String str, String word) {
			String s="";

for(int i=0;i<str.length();i++){
if(str.subtring(i,i+1)!=word)
s+="+";
else
s+=word;
}
return s; 
		} 
		}